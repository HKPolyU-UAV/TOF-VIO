^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package nodelet_tutorial_math
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.11 (2018-03-30)
-------------------
* update to use new pluginlib macros

0.1.8 (2014-11-05)
------------------
* update package maintainer.
* Contributors: Daniel Stonier
