#ifndef EULER_Q_RMATRIX
#define EULER_Q_RMATRIX

#include <eigen3/Eigen/Eigen>
#include <eigen3/Eigen/Dense>

//Ref: https://www.astro.rug.nl/software/kapteyn/_downloads/attitude.pdf
//Tait–Bryan Euler Angle Yaw–Pitch–Roll (Body 3-2-1)
//Pitch-theta
//Roll-psi
//Yaw-phi
//the first rotation is by an angle phi about the z-axis
//the second rotation is by an angle theta in [0,pi] about the former x-axis (now x^')
//the third rotation is by an angle psi about the former z-axis (now z^')
//R=R(alpha)*R(beta)*R(gamma)

using namespace Eigen;

inline Matrix3d rotation_matrix_from_euler(const Vector3d rpy)
{
    //1->yaw
    //2->pitch
    //3->roll
    Matrix3d R;
    Matrix3d Rx,Ry,Rz;

    double phi=rpy(0);//phi
    double theta=rpy(1);//theta
    double psi=rpy(2);//psi


    Rx<< 1, 0,        0,
         0, cos(phi), -sin(phi),
         0, sin(phi), cos(phi);

    Ry<< cos(theta),  0, sin(theta),
         0,           1, 0,
         -sin(theta), 0, cos(theta);

    Rz<< cos(psi), -sin(psi), 0,
         sin(psi), cos(psi),  0,
         0,        0,         1;

    R << Rx*Ry*Rz;

    return R;
}

inline Vector3d euler_from_rotation_matrix(const Matrix3d R)
{
    Vector3d rpy;
//    [                              cos(psi)*cos(theta),                             -cos(theta)*sin(psi),           sin(theta)]
//    [ cos(phi)*sin(psi) + cos(psi)*sin(phi)*sin(theta), cos(phi)*cos(psi) - sin(phi)*sin(psi)*sin(theta), -cos(theta)*sin(phi)]
//    [ sin(phi)*sin(psi) - cos(phi)*cos(psi)*sin(theta), cos(psi)*sin(phi) + cos(phi)*sin(psi)*sin(theta),  cos(phi)*cos(theta)]

    double phi, theta, psi;
    double r11 = R(0,0);
    double r12 = R(0,1);
    double r13 = R(0,2);
    double r23 = R(1,2);
    double r33 = R(2,2);

    theta = asin(r13);
    phi = atan2(-r23/cos(theta),r33/cos(theta));
    psi = atan2(-r12/cos(theta),r11/cos(theta));

    rpy(0) = phi;
    rpy(1) = theta;
    rpy(2) = psi;

    return rpy;
}

#endif
